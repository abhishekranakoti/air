// Collapsible
var coll = document.getElementsByClassName("collapsible");
let firstMessage = ''

for (let i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {
        this.classList.toggle("active");

        var content = this.nextElementSibling;

        if (content.style.maxHeight) {
            content.style.maxHeight = null;
        } else {
            content.style.maxHeight = content.scrollHeight + "px";
        }

    });
}

function getTime() {
    let today = new Date();
    hours = today.getHours();
    minutes = today.getMinutes();

    if (hours < 10) {
        hours = "0" + hours;
    }

    if (minutes < 10) {
        minutes = "0" + minutes;
    }

    let time = hours + ":" + minutes;
    return time;
}

// Gets the first message
async function firstBotMessage(sessionId) {

    networkCall(sessionId).then(async (r) => {
        firstMessage = r.data.Reply.dialogflow_response
        document.getElementById("botStarterMessage").innerHTML = '<p class="botText"><span>' + firstMessage + '</span></p>';
        const question = new SpeechSynthesisUtterance(r.data.Reply.dialogflow_response)
        question.lang = 'hi-IN';
        console.log("split length", r.data.Reply.dialogflow_response.split(' ').length)
        await window.speechSynthesis.speak(question);
    })

    // axios.post('https://bot.pharynxai.com:5000/airtelSmartphone', '', {
    //     params: {
    //         MSG: "नमस्ते",
    //         sessionId: sessionId
    //     }
    // }).then(async (r) => {
    //     console.log("Res", r.data)

    //     firstMessage = r.data.Reply.dialogflow_response
    //     document.getElementById("botStarterMessage").innerHTML = '<p class="botText"><span>' + firstMessage + '</span></p>';
    //     var msg = new SpeechSynthesisUtterance(r.data.Reply.dialogflow_response);
    //     msg.lang = 'hi-IN'
    //     console.log("jh", msg)
    //     speechSynthesis.speak(msg);
    // });

    let time = getTime();
    $("#chat-timestamp").append(time);
    document.getElementById("userInput").scrollIntoView(false);


}

const networkCall = async (sessionId) => {

    const res = await axios.post('https://bot.pharynxai.com:5000/airtelSmartphone', '', {
        params: {
            MSG: 'नमस्ते',
            sessionId: sessionId
        }
    });
    return res
}

// Retrieves the response
function getHardResponse(botText) {
    console.log(botText);
    let botHtml = '<p class="botText"><span>' + botText + '</span></p>';
    $("#chatbox").append(botHtml);

    document.getElementById("chat-bar-bottom").scrollIntoView(true);
}

//Gets the text text from the input box and processes it
function getResponse(userText, resText) {
    //let userText = $("#textInput").val();

    let userHtml = '<p class="userText"><span>' + userText + '</span></p>';

    console.log(userText)

    // $("#textInput").val("");
    $("#chatbox").append(userHtml);
    document.getElementById("chat-bar-bottom").scrollIntoView(true);

    //this timeout is to simulate a delay in the response to the user
    setTimeout(() => {
        getHardResponse(resText);
        //console.log('listening')
    }, 200)

}

// Handles sending text via button clicks
function buttonSendText(sampleText) {
    let userHtml = '<p class="userText"><span>' + sampleText + '</span></p>';
    $("#textInput").val("");
    $("#chatbox").append(userHtml);
    document.getElementById("chat-bar-bottom").scrollIntoView(true);

    //Uncomment this if you want the bot to respond to this buttonSendText event
    // setTimeout(() => {
    //     getHardResponse(sampleText);
    // }, 1000)
}

function sendButton(userText, resText) {
    getResponse(userText, resText);
}

function heartButton() {
    buttonSendText("Heart clicked!")
}

// Press enter to send a message
$("#textInput").keypress(function (e) {
    if (e.which == 13) {
        getResponse();
    }
});